package bg.softuni.java_advanced.iterators_and_comparators.lab.P02_Library;

import java.util.Arrays;
import java.util.List;

public class Book {
    private String title;
    private int year;
    private List<String> authors;

    public Book(String title, int year, String... args) {
        setTitle(title);
        setYear(year);
        setAuthors(args);
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public List<String> getAuthors() {
        return authors;
    }

    private void setTitle(String title) {
        this.title = title;
    }

    private void setYear(int year) {
        this.year = year;
    }

    private void setAuthors(String... authors) {
        this.authors = Arrays.asList(authors);
    }

    @Override
    public String toString() {
        int count = 0;
        return String.format("%s %d %s", this.getTitle(), this.getYear(), this.getAuthors().get(count++)).trim();
    }
}
