package bg.softuni.java_advanced.preparation_exam_28_June_2020.P03_Parking;

public class Main {
    public static void main(String[] args) {

    }
}
