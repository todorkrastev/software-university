package bg.softuni.java_advanced.preparation_exam_16_12_2020.P03_Openning;

public class Main {
    public static void main(String[] args) {

    }
}
