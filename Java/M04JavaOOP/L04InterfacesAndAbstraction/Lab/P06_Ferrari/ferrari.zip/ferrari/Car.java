package ferrari;

public interface Car {
    String MODEL = "488-Spider";

    String brakes();

    String gas();
}
