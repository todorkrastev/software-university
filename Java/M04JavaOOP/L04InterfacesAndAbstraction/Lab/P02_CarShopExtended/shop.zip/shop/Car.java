package shop;

public interface Car {
    Integer TYRES = 4;

    String getModel();

    String getColor();

    Integer getHorsePower();

    String countryProduced();
}
