package militaryElite.interfaces;

public interface LieutenantGeneral {

    void addPrivate(Private soldier);
}
