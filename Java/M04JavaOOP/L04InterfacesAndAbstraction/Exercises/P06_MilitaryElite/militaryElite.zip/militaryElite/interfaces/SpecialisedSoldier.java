package militaryElite.interfaces;

public interface SpecialisedSoldier {

    String getCorps();
}
