package militaryElite.interfaces;

public interface Private extends Soldier {

    double getsSalary();
}
