package citizen;

public interface Person {
    String getName();
    int getAge();
}
