package food;

public interface Birhtable {
    String getBirthDate();
}
