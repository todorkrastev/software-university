package food;

public interface Identifiable {
    String getId();
}
