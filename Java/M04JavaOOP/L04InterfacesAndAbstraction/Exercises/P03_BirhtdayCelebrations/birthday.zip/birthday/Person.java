package birthday;

public interface Person {
    String getName();
    int getAge();
}
