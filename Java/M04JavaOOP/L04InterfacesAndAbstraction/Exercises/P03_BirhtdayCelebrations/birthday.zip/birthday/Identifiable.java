package birthday;

public interface Identifiable {
    String getId();
}
