package P07_CollectionHierarchy;

public interface Addable {
    int add(String item);
}
