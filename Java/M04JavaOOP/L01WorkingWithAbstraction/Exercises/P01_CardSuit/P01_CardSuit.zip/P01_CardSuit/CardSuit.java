package P01_CardSuit;

enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
