package solidLab.p01_SingleResponsibility.p01_DrawingShape.interfaces;

public interface DrawingRepository {
}
