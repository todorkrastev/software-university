package solidLab.p05_DependencyInversion.p02_Worker;

public class Worker {
    public void work(){
        //work
    }
}
