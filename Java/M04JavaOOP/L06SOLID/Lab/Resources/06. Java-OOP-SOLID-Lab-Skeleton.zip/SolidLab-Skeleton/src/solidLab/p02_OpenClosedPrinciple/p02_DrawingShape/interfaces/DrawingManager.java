package solidLab.p02_OpenClosedPrinciple.p02_DrawingShape.interfaces;

public interface DrawingManager {
    void draw(Shape shape);
}
