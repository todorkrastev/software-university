package solidLab.p02_OpenClosedPrinciple.p03_ShoppingCart;

public class OnlineOrder extends Order {

    protected OnlineOrder(Cart cart) {
        super(cart);
    }
}
