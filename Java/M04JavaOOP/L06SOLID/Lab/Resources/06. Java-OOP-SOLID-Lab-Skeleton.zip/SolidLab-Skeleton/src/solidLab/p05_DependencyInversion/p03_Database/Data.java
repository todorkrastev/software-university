package solidLab.p05_DependencyInversion.p03_Database;

public class Data {
    public Iterable<Integer> courseIds()
    {
        // return course ids
        return null;
    }

    public Iterable<String> courseNames()
    {
        // return course names
        return null;
    }

    public Iterable<String> search(String substring)
    {
        // return found results
        return null;
    }

    public String getCourseById(int id)
    {
        // return course by id
        return null;
    }
}
