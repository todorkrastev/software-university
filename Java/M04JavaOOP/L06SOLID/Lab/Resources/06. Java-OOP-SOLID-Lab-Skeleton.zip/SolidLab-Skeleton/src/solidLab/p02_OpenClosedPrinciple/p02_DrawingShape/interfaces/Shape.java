package solidLab.p02_OpenClosedPrinciple.p02_DrawingShape.interfaces;

public interface Shape {

}
