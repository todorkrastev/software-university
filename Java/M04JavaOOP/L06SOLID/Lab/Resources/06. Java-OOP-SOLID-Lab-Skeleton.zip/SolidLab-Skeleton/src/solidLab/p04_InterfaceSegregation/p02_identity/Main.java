package solidLab.p04_InterfaceSegregation.p02_identity;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
