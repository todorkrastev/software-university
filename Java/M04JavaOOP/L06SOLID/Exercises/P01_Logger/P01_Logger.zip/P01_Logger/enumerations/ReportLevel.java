package P01_Logger.enumerations;

public enum ReportLevel {
    INFO,
    WARNING,
    ERROR,
    CRITICAL,
    FATAL,
}
