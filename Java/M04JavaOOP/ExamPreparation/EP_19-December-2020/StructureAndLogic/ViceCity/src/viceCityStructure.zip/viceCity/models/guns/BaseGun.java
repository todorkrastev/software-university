package viceCity.models.guns;

public abstract class BaseGun implements Gun{
    private String name;
    private int bulletsPerBarrel;
    private int totalBullets;
    private boolean canFire;

    protected BaseGun(String name, int bulletsPerBarrel, int totalBullets) {
        this.setName(name);
        this.setBulletsPerBarrel(bulletsPerBarrel);
        this.setTotalBullets(totalBullets);
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setBulletsPerBarrel(int bulletsPerBarrel) {
        this.bulletsPerBarrel = bulletsPerBarrel;
    }

    private void setTotalBullets(int totalBullets) {
        this.totalBullets = totalBullets;
    }

    private void setCanFire(boolean canFire) {
        this.canFire = canFire;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getBulletsPerBarrel() {
        return 0;
    }

    @Override
    public boolean canFire() {
        return false;
    }

    @Override
    public int getTotalBullets() {
        return 0;
    }

    @Override
    public int fire() {
        return 0;
    }
}
