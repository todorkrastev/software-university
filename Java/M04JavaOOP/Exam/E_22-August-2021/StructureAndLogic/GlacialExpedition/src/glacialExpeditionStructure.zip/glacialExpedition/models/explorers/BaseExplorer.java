package glacialExpedition.models.explorers;

import glacialExpedition.models.suitcases.Carton;
import glacialExpedition.models.suitcases.Suitcase;

public abstract class BaseExplorer implements Explorer{
    private String name;
    private double energy;
    private Suitcase suitcase;

    protected BaseExplorer(String name, double energy) {
        this.setName(name);
        this.setEnergy(energy);
        this.setSuitcase();
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setEnergy(double energy) {
        this.energy = energy;
    }

    private void setSuitcase() {
        this.suitcase = new Carton();
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public double getEnergy() {
        return 0;
    }

    @Override
    public boolean canSearch() {
        return false;
    }

    @Override
    public Suitcase getSuitcase() {
        return null;
    }

    @Override
    public void search() {

    }
}
