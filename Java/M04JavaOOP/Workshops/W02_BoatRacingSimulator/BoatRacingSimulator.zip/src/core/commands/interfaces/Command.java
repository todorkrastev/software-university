package core.commands.interfaces;

public interface Command {
    String execute(String[] args);
}
