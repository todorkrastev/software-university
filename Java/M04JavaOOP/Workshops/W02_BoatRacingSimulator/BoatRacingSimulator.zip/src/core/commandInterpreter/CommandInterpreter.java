package core.commandInterpreter;

public interface CommandInterpreter {
    String interpret(String type, String[] args);
}
