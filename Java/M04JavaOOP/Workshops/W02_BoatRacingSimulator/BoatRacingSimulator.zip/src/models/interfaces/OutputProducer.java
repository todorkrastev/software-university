package models.interfaces;

public interface OutputProducer {
    int getOutput();
}
