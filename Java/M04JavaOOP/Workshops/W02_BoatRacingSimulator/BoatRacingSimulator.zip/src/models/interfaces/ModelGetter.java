package models.interfaces;

public interface ModelGetter {
    String getModel();
}
