package models.interfaces;

import models.Race;

public interface SpeedCalculator {
    double calcSpeed(Race race);
}
