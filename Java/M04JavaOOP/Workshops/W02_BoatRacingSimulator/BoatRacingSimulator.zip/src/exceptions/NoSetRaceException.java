package exceptions;

public class NoSetRaceException extends Exception {
    public NoSetRaceException(String message) {
        super(message);
    }
}
