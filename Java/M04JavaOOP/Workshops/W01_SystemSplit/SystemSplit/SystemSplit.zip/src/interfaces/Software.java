package interfaces;

public interface Software {

    String getName();

    int getCapacityConsumption();

    int getMemoryConsumption();
}
