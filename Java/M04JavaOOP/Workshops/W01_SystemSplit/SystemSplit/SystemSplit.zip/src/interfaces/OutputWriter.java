package interfaces;

public interface OutputWriter {
    void write(String output);
}
