package interfaces;

public interface InputReader {
    String readLine();
}
